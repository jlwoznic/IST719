#
# lab 10: App 1
#
library(shiny)
library(lubridate)

server <- function(input, output)
{
 
}

ui <- fluidPage
(
  mainPanel(paste("Joyce's Shiny App at ", now()))
)

shinyApp(ui,server)

